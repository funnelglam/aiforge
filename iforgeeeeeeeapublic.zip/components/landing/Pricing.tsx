export default function Pricing() {
  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <h2 className="text-4xl font-bold">
          Pricing
        </h2>
      </div>
    </section>
  );
}